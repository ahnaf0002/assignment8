import React from 'react';
 
 

const Home = () => {
    return (
        <div>
          <h5>This is our home page to track our income and expense</h5>
        </div>
    );
};

export default Home;